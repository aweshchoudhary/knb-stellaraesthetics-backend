id: int
deal_id: ForeignKey(deal_id)
stage_id:
timestamp: