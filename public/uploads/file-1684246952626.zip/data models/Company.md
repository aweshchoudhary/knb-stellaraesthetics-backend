d: int autoincriment
title: str
desc: str
datecreated: datetime
last_modified: datetime
address: str