id: int autoincriment
title: str
desc: str
datecreated: datetime
last_modified: datetime
pipeline_id: ForeignKey(pipline_id)
curr_stage_id: ForeignKey()
product_service: List(ForeignKey(deal_product_service_id)
quantity: int
deal_value: int
currency: ForeignKey
owner: ForeignKey(user_id)
assignees: List(ForeignKey(user_id))