id: int
product_id:ForeignKey(product)
created_time: datetime
edited_time: datetime
rate: int
total: int
currency: ForeignKey(currency)
created_by: ForeignKey(user)
tax_percentage: int
discount: int(18)