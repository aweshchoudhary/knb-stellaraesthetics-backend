id: int
deal_id: List(ForeignKey(deal))
title: str
desc: Optinal(str)
type:Choice(email|call|task|message|meeting)
start_time: datetime
end_time: datetime
additional_fields: Location|Link
performer: ForeignKey(user)
involved_contacts: List(ForeignKey(conatct))
involved_users: List(ForeignKey(user))
completed_on: Optional(datetime)