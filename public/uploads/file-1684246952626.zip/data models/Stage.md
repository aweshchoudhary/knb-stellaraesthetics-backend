id: int autoincriment
name: str
desc: str
datecreated: datetime
last_modified: datetime
pipeline_id: ForeignKey(pipeline)