id: int
startTime: datetime
endTime: datetime
user: ForeignKey(user)
contact: ForeignKey(contact)
deal_id: ForeignKey(user)
from_me: bool(True|False)
