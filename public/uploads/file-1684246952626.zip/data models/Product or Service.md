id: int
name: str
desc: str
created_time: datetime
edited_time: datetime
type: choice(product|service)
rate: int
currency: ForeignKey(currency)
created_by: ForeignKey(user)
quantity_type:choice(unit|time_peroid(yr/mo/day/hr/min/sec)|flatfee)
tax_percentage: int