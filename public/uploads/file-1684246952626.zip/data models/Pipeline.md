id: int autoincriment
name: str
desc: str
datecreated: datetime
last_modified: datetime
stages: list(stage_ids)
product_service: ForeignKey(product_service)
