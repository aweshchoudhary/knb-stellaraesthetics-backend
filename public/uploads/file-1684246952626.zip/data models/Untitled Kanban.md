---

kanban-plugin: basic

---

## 



## 



## 



## 





%% kanban:settings
```
{"kanban-plugin":"basic"}
```
%%