id: int autoincriment
title: str
desc: str
datecreated: datetime
last_modified: datetime
source: ForeignKey(source_id)
company: company_id
address: str