id: int
uploader: ForeignKey(user|user)
deal_id: ForeignKey(user)
involved_users: List(ForeignKey(user))
involved_contacts: List(ForeignKey(contact))
sent_to_contact:List(ForeignKey(contact))
sent_to_user:List(ForeignKey(user))