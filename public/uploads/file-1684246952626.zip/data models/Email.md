id: int
startTime: datetime
endTime: datetime
sender: ForeignKey(user)
receiver: ForeignKey(contact)
deal_id: ForeignKey(user)
involved_users: List(ForeignKey(user))
involved_contacts: List(ForeignKey(contact))